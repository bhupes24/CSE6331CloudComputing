import urllib
from flask import Flask, render_template
from sqlalchemy import create_engine
import os

params = urllib.parse.quote_plus(r'Driver={ODBC Driver 17 for SQL Server};Server=tcp:trial6331dbserver.database.windows.net,1433;Database=triall6331db;Uid=trial6331admin;Pwd=Admin6331;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
conn_str = 'mssql+pyodbc:///?odbc_connect={}'.format(params)
engine_azure = create_engine(conn_str,echo=True)

print('connection is ok')
print(engine_azure.table_names())

app = Flask(__name__)
PICTURE_FOLDER = os.path.join('static','pictures')
app.config['UPLOAD_FOLDER'] = PICTURE_FOLDER



@app.route('/')
def index():
    full_filename = os.path.join(app.config['UPLOAD_FOLDER'], 'm.jpg')
    return render_template("Hello.html", user_image=full_filename)



if __name__ == '__main__':
    app.run(debug=True)
